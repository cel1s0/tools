#ifndef _GET_PID_H
#define _GET_PID_H

int find_pid(DWORD *ppid);

#endif
