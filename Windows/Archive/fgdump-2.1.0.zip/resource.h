//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by fgdump.rc
//
#define IDR_PSTGDUMP                    130
#define IDR_FGEXEC                      149
#define IDR_BIN1                        152
#define IDR_BIN2                        157
#define IDR_BIN3                        173
#define IDR_CACHEDUMP64                 174
#define IDR_CACHEDUMP                   175
#define IDR_LSAEXT64                    176
#define IDR_LSAEXT                      177
#define IDR_PWDUMP                      178
#define IDR_PWSERVICE64                 179
#define IDR_BIN4                        180
#define IDR_PWSERVICE                   180

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        181
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
